const but  = document.querySelectorAll('btn btn-outline-primary')[3]; 
