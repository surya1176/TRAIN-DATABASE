const mysql = require("mysql"); 
const express  = require("express"); 
const app = express(); 
const path =require('path')
const bodyParser = require("body-parser");
const { resolvePreset } = require("@babel/core");
const encoder = bodyParser.urlencoded();  
const cookieParser = require("cookie-parser");
const sessions = require('express-session');
const { connect } = require("http2");
app.use(express.static(path.join(__dirname, 'public')));
var nodemailer = require('nodemailer');
let transporter = nodemailer.createTransport({
    service: 'gmail',
    port : 587, 
    secure : false, 
    requireTLS : true,
    auth: {
    user : 'cse210001041@iiti.ac.in',
    pass : 'oobbmrqhpafsgqjv'
    }
  }); 


  var mailOptions  = { 
    from : 'cse210001041@iiti.ac.in', 
    to: 'cse210001024@iiti.ac.in', 
    subject : 'Hi', 
    text : 'Loss'
  }

  transporter.sendMail(mailOptions,function(error,info){ 
    if(error){ 
        console.log(error);
    }
    else{ 
        console.log("hi");
    }
  })


app.set('view engine', 'ejs');
app.use(cookieParser());
const oneDay = 10000000 * 60 * 60 * 24;
app.use(sessions({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false
}));7
//app.set('views', path.join(__dirname, 'views'))
app.use("/assets",express.static("assets"));
const connection = mysql.createConnection({ 
    host : "localhost", 
    user : "root",
    password : '',
    // password : "$your_password$",
    database : "nodejs"
}); 




connection.connect(function(error){ 
    if(error) throw error
    else console.log("connected to database successfuly!")
}) 

app.get("/home",function(req,res){ 
   console.log(req.session);
    if(req.session.bsa){ 
        res.render('index3', {user : req.session.bsa} );
    }
    else{
    // res.sendFile(__dirname + "/index3.html"); 
    res.render('index3');
    }
    
}) 

app.get("/index11.html",function(req,res){ 
    
    res.render('index3', {user : "surya"});

})

app.get("/index.html",function(req,res){ 
    
    res.render('index');

})
app.get("/index10.html",function(req,res){ 
    res.render('index3',{message : "hi"});
    req.session = {}
    console.log(req.session);
})
app.get("/index2.html",function(req,res){ 
    
    res.sendFile(__dirname + "/train/index2.html"); 

}) 
app.get("/index5.html",function(req,res){ 
    
    res.sendFile(__dirname + "/train/index5.html"); 

}) 

app.get("/index6.html",function(req,res){ 
    
    res.sendFile(__dirname + "/train/index6.html"); 

})
app.get("/register.html",function(req,res){ 
   
    res.render('register');

})
app.get("/index.html",function(req,res){ 
    
    res.sendFile(__dirname + "/index.html"); 

})
app.get("/index3.html",function(req,res){ 
    res.sendFile(__dirname + "/train/index7.html")
}) 
var session2;
app.post("/",encoder, function(req,res){
    
    var username = req.body.username;
    var password = req.body.password; 

    connection.query("select * from costumer where user_name = ? and user_pass = ?",[username,password],function(error,results,fields){ 
        req.session.bsa = username;
        if (results.length >0) { 
           if(username=="surya"){ 
            res.render('index4')  
                 }
                 else{
           
            res.render('index3', {user : username} );
                 }
        } else {
           res.render('index',{message : "email/password doesnot match"});
            
        }
        res.end();
    }); 

}); 
app.get("/index12.html",function(req,res){ 
    
    res.sendFile(__dirname + "/train/index7.html"); 

})
app.post("/traindelete",encoder,function(req,res){ 
    var trid = req.body.idt;
    connection.query("select * from costumer where train_id",[trid],function(error,results,fields){ 
        for(var i=0;i<results.length;i++){ 
            var em = results[i].email_id;
            var mailOptions  = { 
                from : 'cse210001041@iiti.ac.in', 
                to: em, 
                subject : 'Cancellation of ticket due to failure', 
                text : 'This mail is to inform you that your booking with happyeasygo has been terminated due to failure. You will be refunded within 2 days.Sorry for the inconvinience caused'
              }
            
              transporter.sendMail(mailOptions,function(error,info){ 
                if(error){ 
                    console.log(error);
                }
                else{ 
                    console.log("hi");
                }
              })
        }
    

})
})

var obj = {} ;
app.post("/trainupdate",encoder,function(req,res){ 
    var trid = req.body.idt; 
    connection.query("select * from train_stops",function(error1,results1,fields1){ 
        
    connection.query("select * from stops_at where train_id=?",[trid],function(error,results,fields){ 
        connection.query("select * from train where train_id=?",[trid],function(error2,results2,fields2){ 
      
         
            obj.print3 =results1;
            obj.print2 = results2;
            obj.print = results;
          
            res.render('results',{obj});
         
    })
    })
  
})   
        
        
  
    
    
 
}) 
app.post("/re",encoder,function(req,res){ 
   var name = req.body.name;
   var email = req.body.email;
    var password = req.body.password; 
    var cpassword = req.body.cpassword; 
    
   if(!password){ 
    res.render('register', {message: "please enter a password"});
   }
   else  if(password != cpassword){
       res.render('register', {message: "password fields are diffrent"});
   } 
   else{  

    connection.query("select * from costumer where email_id = ? ",[email],function(error,results,fields){  
        if (results.length >0) {
        res.render('register', {message: "email id is already registered"});
        } 
        else{
    connection.query("select * from costumer where user_name = ? ",[name],function(error1,results1,fields1){ 
        if (results1.length >0) {
            res.render('register', {message: "username is already taken"});
        } 
        else{
            req.session.bsa = name;
    var sql = "INSERT INTO costumer (user_name,email_id,user_pass,wallet) VALUES (?,?,?,?)";
    connection.query(sql, [name,email,password,1000], function (err, result) {
        if (err) throw err; 

        console.log("Number of records inserted: " + result.affectedRows); 
        res.render('index3', {user : name, emailid : email} );
      });

   } 
});
       
        
  
} 
});

   } 
});
var obj1 ={}
app.post("/ticket",encoder,function(req,res){
  var from =  req.body.from; 
  var to = req.body.to; 
  
  req.session.date = req.body.date; 
  connection.query("select * from train where startlocation = ? and endlocation = ? ",[from,to],function(error,results,fields){
    if(results.length>0){ 
    req.session.user = results;
    
    res.render('trains', {message : req.session });
    }
    else{ 
        console.log("loss");
    }
})
})


app.post("/results",function(req,res){ 
    
    var result = (req.session); 
   // console.log(result);
    res.render("submit",{message : result});
})
app.get("/welcome",function(req,res){
    res.sendFile(__dirname + "/welcome.html")
})
app.post("/r",encoder,function(req,res){ 
    var train_id = req.body.cars;
    var seat = req.body.seatstype;
    var fname = req.body.fname; 
    var mname = req.body.mname;
    var lname = req.body.lname; 
    var occupation = req.body.occupation; 
    var dateofbirth = req.body.DOB; 
    var sex = req.body.sex; 
    var email = req.body.email; 
    var number = req.body.mobileno; 
    var fno =req.body.fno; 
    var lane = req.body.lane; 
    var area  = req.body.area; 
    var state  = req.body.state; 
    var pincode =  req.body.pincode; 
    var city =req.body.city; 
    var count = req.body.number;
    console.log(req.body);
    if(!train_id || !seat || !fname || !mname || !lname || !occupation || !dateofbirth || !sex || !email || !number || !fno || !lane ||!area || !state || !pincode ||!city ){ 
        
        req.session.loss ="please enter all the fields"; 
        console.log(req.session);
         res.render('submit', {message : req.session});
         

    } 
     else{ 
        if(req.session.bsa){ 
            var username = req.session.bsa; 
            connection.query("select id from costumer where user_name = ? ",[username],function(error,results,fields){ 
                req.body.id = results[0].id ; 
            })
            connection.query("select email_id from costumer where user_name = ? ",[username],function(error,results,fields){ 
        
            //    console.log(results[0].email_id);
                if(email!=results[0].email_id){ 
                    req.session.loss= "registered emailid doesnot match with entered emailid";
                    console.log(req.session);
                    res.render('submit', {message : req.session});
                }
                else{ 
                    console.log("hi");
                    var sql = "UPDATE costumer set FirstName = ? where user_name = ?";
                    connection.query(sql, [fname,username], function (err, result) {
                        if (err) throw err;
                       console.log("Number of records inserted: " + result.affectedRows); 
                })
                var sql = "UPDATE costumer set MiddleName = ? where user_name = ?";
                connection.query(sql, [mname,username], function (err, result) {
                    if (err) throw err;
                   console.log("Number of records inserted: " + result.affectedRows); 
            })  
            var sql = "UPDATE costumer set LastName = ? where user_name = ?";
            connection.query(sql, [lname,username], function (err, result) {
                if (err) throw err;
               console.log("Number of records inserted: " + result.affectedRows); 
        }) 
        var sql = "UPDATE costumer set Occupation = ? where user_name = ?";
        connection.query(sql, [occupation,username], function (err, result) {
            if (err) throw err;
           console.log("Number of records inserted: " + result.affectedRows); 
    }) 
    var sql = "UPDATE costumer set dateofbirth = ? where user_name = ?";
    connection.query(sql, [dateofbirth,username], function (err, result) {
        if (err) throw err;
       console.log("Number of records inserted: " + result.affectedRows); 
}) 
var sql = "UPDATE costumer set gender = ? where user_name = ?";
connection.query(sql, [sex,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
}) 
var sql = "UPDATE costumer set mobilenumber = ? where user_name = ?";
connection.query(sql, [number,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
}) 
var sql = "UPDATE costumer set FlatNo = ? where user_name = ?";
connection.query(sql, [fno,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
}) 
var sql = "UPDATE costumer set street = ? where user_name = ?";
connection.query(sql, [lane,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
var sql = "UPDATE costumer set area = ? where user_name = ?";
connection.query(sql, [area,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
var sql = "UPDATE costumer set state = ? where user_name = ?";
connection.query(sql, [state,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
var sql = "UPDATE costumer set pincode = ? where user_name = ?";
connection.query(sql, [pincode,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
var sql = "UPDATE costumer set city = ? where user_name = ?";
connection.query(sql, [city,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
var sql = "UPDATE costumer set train_id = ? where user_name = ?";
connection.query(sql, [train_id,username], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})


if(seat=="seater"){
    console.log(req.session.date);
connection.query("select * from availability where travel_date = ?",[req.session.date],function(error4,results4,fields4){ 
    console.log(results4)
    console.log(count);
var amjt = parseInt(results4[0].seater)-parseInt(count); 
console.log(amjt);
connection.query("UPDATE availability set seater = ? where travel_date = ?",[amjt,req.session.date], function (err, result) {
    if (err) throw err;
   console.log("Number of records inserted: " + result.affectedRows); 
})
})

}
    
   
    connection.query("select basecost from train where train_id = ? ",[train_id],function(error,results,fields){ 
        var date1 = req.session.date 
        let today1 = new Date()
        var pay1 = results[0].basecost; 
        console.log(pay1);
        if(seat=="sleepernonac"){ 
              pay1 += parseInt(pay1) + 150;
              console.log(pay1);
        }
        if(seat=="sleeperac"){ 
         pay1 +=100;
         console.log(pay1);
        }
        console.log(count);
        pay1 =  pay1*count; 
        console.log(date1);
        console.log(new Date(date1).getMonth()); 
        console.log(today1);
        console.log(new Date(today1).getMonth());
        if(new Date(date1).getMonth()-new Date(today1).getMonth()==0){ 
            pay1 += 50;
        }
        req.body.price = pay1;

        connection.query("select * from costumer where user_name = ?",[req.session.bsa],function(err,result){ 
            console.log(pay1);
            console.log(result[0].wallet)
            var ans = result[0].wallet-pay1; 
            console.log(ans);
            connection.query("UPDATE costumer set wallet = ? where user_name = ?", [ans,req.session.bsa], function (err1, result1) {   
                if (err) throw err;
                console.log("Number of records inserted: " + result1.affectedRows); 
        })
    })
    var sql = "INSERT INTO ticket (seats,date_of_travel,class,cost) VALUES (?,?,?,?)";
    connection.query(sql, [count,date1,seat,pay1], function (err, result) {
        if (err) throw err;
       console.log("Number of records inserted: " + result.affectedRows); 
}) 
                
connection.query("select ticket_id from ticket where seats = ? and date_of_travel = ? and class = ? and cost = ?", [count,date1,seat,pay1],function(error,results,fields){ 
    console.log(results[results.length-1]);
    req.body.tid = results[results.length-1].ticket_id ; 

console.log(req.body.tid)
let today = new Date().toLocaleDateString()


console.log(today);
var sql = "INSERT INTO books (id,ticket_id,booking_date) VALUES (?,?,?)";
    connection.query(sql, [req.body.id,req.body.tid,today], function (err, result) {
        if (err) throw err;
       console.log("Number of records inserted: " + result.affectedRows); 
}) 
var sql = "INSERT INTO for_train (train_id,ticket_id) VALUES (?,?)";
    connection.query(sql, [train_id,req.body.tid], function (err, result) {
        if (err) throw err;
       console.log("Number of records inserted: " + result.affectedRows); 
}) 
console.log(train_id); 

console.log(req.body.tid);
req.body.trid = train_id;
    req.body.gois = req.session.date;
    req.body.start = req.session.user[0].startlocation;
    req.body.end = req.session.user[0].endlocation;
    const date = new Date();
    req.body.cur = date;
    console.log('hi');
      res.render('tickets',{message : req.body});
    })

            }) 
        
        }
    }) 
}
     
     else{  
         req.session.loss= "please register/login before you book ticket";
                    console.log('lol loss');
                    res.render('submit', {message : req.session}); 

     }
     
    }
    
    



 
}) 
app.get("/index4.html",function(req,res){ 
    connection.query("select id from costumer where user_name = ? ",[req.session.bsa],function(error,results,fields){ 
         if(results.length>0){ 
             var id = results[0].id; 
             console.log("hi");
             var os ={}
             connection.query("select ticket_id from books where id = ? ",[id],function(error1,results1,fields1){ 
                if(results1.length>0){
                    os.tickid = results1[0].ticket_id; 
                    console.log(os.tickid)
                    connection.query("select train_id from for_train where ticket_id = ? ",[os.tickid],function(error2,results2,fields2){ 
                            os.train_id = results2[0].train_id; 
                    
                    connection.query("select seats from ticket where ticket_id = ? ",[os.tickid],function(error2,results2,fields2){ 
                        os.seats = results2[0].seats; 
               
                connection.query("select cost from ticket where ticket_id = ? ",[os.tickid],function(error2,results2,fields2){ 
                    os.cost = results2[0].cost; 
   
            connection.query("select class from ticket where ticket_id = ? ",[os.tickid],function(error2,results2,fields2){ 
                os.class = results2[0].class; 
     
        console.log(os);
        res.render('cancel',{message : os});
    })
})
})
})
    }
    else{ 
        res.render('cancel')
    }
    }) 

       
    }
      
         else{ 
            res.render('cancel'); 
         }
})
}) 


app.get("/me",function(req,res){
    var us = req.session.bsa;
    console.log(us) 
    connection.query("select * from costumer where user_name = ?",[us],function(err,result){ 
        console.log(result);
        connection.query("select * from books where id= ?",[result[0].id],function(err1,result1){ 
            connection.query("select * from ticket where ticket_id= ?",[result1[0].ticket_id],function(err2,result2){ 
                var ct = parseInt(result2[0].seats);
                var payt = result2[0].cost;
                var rest = result2[0].booking_date; 
                let today = new Date()
                var amnt = parseInt(payt);
                if(new Date(rest).getMonth()-new Date(today).getMonth()==0){ 
                    amnt/=2; 
                    console.log("byue")
                }
                var wal =  parseInt(result[0].wallet);
                var final = amnt+wal;
             connection.query("UPDATE costumer set wallet = ? where user_name = ?", [final,req.session.bsa], function (err4, result4) {   
                        if (err) throw err;
                        console.log("Number of records inserted: " + result4.affectedRows); 
                        
                })

                connection.query("DELETE FROM ticket  where ticket_id = ?", [result2[0].ticket_id], function (err4, result4) {   
                    if (err) throw err;
                    console.log("Number of records inserted: " + result4.affectedRows); 
                    
            })

            
            })
        })
    })
                

})






app.listen(4000);


